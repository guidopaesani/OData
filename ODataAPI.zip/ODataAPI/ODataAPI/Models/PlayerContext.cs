﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ODataAPI.Models
{
    public class PlayersContext : DbContext
    {
        public PlayersContext(DbContextOptions options) : base(options) 
        {
            if(!this.Database.EnsureCreated())
            {
                SeedDatabase.Seed(this);
            }
        }

        public DbSet<Player> Players { get; set; }
        public DbSet<Team> Teams { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Team>()
                .HasMany(x => x.Players)
                .WithOne(x => x.Team)
                .HasForeignKey(x => x.TeamId);

                    }
    }
}
