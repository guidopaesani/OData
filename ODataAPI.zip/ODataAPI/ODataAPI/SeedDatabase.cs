﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ODataAPI.Models;

namespace ODataAPI
{
    public static class SeedDatabase
    {           
        private static List<Player> players;
        private static List<Team> teams;

        public static void Seed(PlayersContext context)
        {
            AddTeams(context);
            AddPlayers(context);
        }

      

        private static void AddPlayers(PlayersContext context)
        {
            players = new List<Player>
            {
               new Player
               {
                   Name = "Michael Jordan",
                   Height = 198,
                   Position = Position.Guard,
                   TeamId = 1,
               },
                 new Player
               {
                   Name = "Shaquille O Neal",
                   Height = 215,
                   Position = Position.Center,
                   TeamId = 2,
               },
                   new Player
               {
                   Name = "Kobe Bryant",
                   Height = 198,
                   Position = Position.Guard,
                   TeamId = 2,
               },
                     new Player
               {
                   Name = "Lebron James",
                   Height = 206,
                   Position = Position.Forward,
                   TeamId = 3,
               }
            };
            if (!context.Players.Any())
            {
                context.Players.AddRange(players);
                context.SaveChanges();
            }
        }

        private static void AddTeams(PlayersContext context)
        {
            teams = new List<Team>
            {
                new Team
                {                    
                    Name = "Chicago Bulls",
                    Arena = "United Center",                    
                },
                 new Team
                {                 
                    Name = "Los Angeles Lakers",
                    Arena = "Stables Center",
                },
                  new Team
                {                   
                    Name = "Miami Heat",
                    Arena = "Fedex Forum",
                },
            };

            if (!context.Teams.Any())
            {
                context.Teams.AddRange(teams);
                context.SaveChanges();
            }
        }   
    }
}