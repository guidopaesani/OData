﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ODataAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace ODataAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/Teams")]
    public class TeamsController : Controller
    {
        private readonly PlayersContext context;
        public TeamsController(PlayersContext context)
        {
            this.context = context;
        }
        [HttpGet]
        //public IEnumerable<Player> Get() => context.Players.Include(r => r.Books).ThenInclude(b => b.Publisher)
        public IEnumerable<Team> Get() => context.Teams.Include(x => x.Players).ToList();
    }
}